"""测试角色 Prompt 模块"""

from roles.prompts import get_role_prompt, ROLE_PROMPTS


def test_all_roles_have_prompts():
    for role in ("werewolf", "seer", "witch", "hunter", "villager"):
        assert role in ROLE_PROMPTS
        assert len(get_role_prompt(role)) > 20


def test_witch_prompt_mentions_knife_rule():
    prompt = get_role_prompt("witch")
    assert "刀口" in prompt or "tonight_death" in prompt


def test_hunter_prompt_mentions_can_shoot():
    prompt = get_role_prompt("hunter")
    assert "can_shoot" in prompt
