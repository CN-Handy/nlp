from schema.system_config import load_system_config, DEFAULT_CONFIG_PATH

config = load_system_config()
