import os
from pathlib import Path

from pydantic import BaseModel, Field, model_validator

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "system_config.json"


class SystemConfig(BaseModel):
    base_url: str = Field(default="https://dashscope.aliyuncs.com/compatible-mode/v1", description="模型服务地址")
    api_key: str = Field(default="", description="模型认证API Key")
    default_model: str = Field(default="qwen-flash", description="默认模型名称")

    @model_validator(mode="after")
    def after_load_hook(self) -> "SystemConfig":
        env_key = (
            os.environ.get("OPENAI_API_KEY")
            or os.environ.get("DASHSCOPE_API_KEY")
            or os.environ.get("API_KEY")
        )
        if env_key:
            self.api_key = env_key
        env_base_url = os.environ.get("OPENAI_BASE_URL")
        if env_base_url:
            self.base_url = env_base_url
        if self.api_key:
            os.environ["OPENAI_API_KEY"] = self.api_key
        if self.base_url:
            os.environ["OPENAI_BASE_URL"] = self.base_url
        return self

    def require_api_key(self) -> None:
        if not self.api_key or self.api_key.startswith("your-"):
            raise ValueError(
                "未配置 LLM API Key。请在 config/system_config.json 填写 api_key，"
                "或设置环境变量 OPENAI_API_KEY / DASHSCOPE_API_KEY。"
            )


def load_system_config(file_path: str | Path | None = None) -> SystemConfig:
    path = Path(file_path) if file_path else DEFAULT_CONFIG_PATH
    if not path.is_file():
        raise FileNotFoundError(f"配置文件不存在: {path}")
    with open(path, "r", encoding="utf-8") as f:
        json_data = f.read()
    return SystemConfig.model_validate_json(json_data)
