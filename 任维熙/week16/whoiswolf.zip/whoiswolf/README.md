# WhoIsWolf — AI 狼人杀 Agent Team

基于多 Agent 的狼人杀对局系统，参考 `evo-werewolf-agent` 实现。

## 规则要点（标准 6 人局）

- **屠边**：狼人胜 = 神职全灭 **或** 村民全灭；好人胜 = 狼人全灭
- **女巫**：解药未用时可见刀口（`tonight_death`）；解药用完后不可见
- **猎人**：`can_shoot` 写入角色状态；被毒杀后无法开枪

## 安装

```bash
cd homework/week16
pip install -r requirements.txt
cp config/system_config.example.json config/system_config.json
# 编辑 config/system_config.json 或设置环境变量 OPENAI_API_KEY
```

## 运行

```bash
# CLI 演示
python main_demo.py

# API 服务（终端 1）
uvicorn api.server:app --reload --host 0.0.0.0 --port 8000

# Vue 观战前端（终端 2）
cd frontend
npm install
npm run dev
# 浏览器打开 http://localhost:5173

# 测试
pytest tests/ -q
```

详细设计见 [whoiswolf.md](./whoiswolf.md)。
