# WhoIsWolf — AI 狼人杀 Agent Team 开发文档

> **项目路径**：`homework/week16/`  
> **参考实现**：`第16周：数字员工RPA、Manus和OpenClaw/evo-werewolf-agent/`  
> **作业目标**：多 Agent 协作与信息不对称博弈；对局引擎驱动回合；结构化日志可观测；可选观战 UI。

---

## 1. 项目概述

### 1.1 核心问题

狼人杀是典型的**不完全信息博弈**：每个玩家只能看到与自己角色相关的私有信息，白天发言与投票又要求多轮自然语言交互。本项目的本质是：

| 维度 | 要求 |
|------|------|
| **多 Agent** | 每名玩家 = 独立 LLM Agent，目标、策略、行动空间因角色而异 |
| **信息隔离** | 引擎严格下发「可见上下文」，禁止 Agent「开天眼」 |
| **对局引擎** | 法官角色：状态机、回合流转、规则裁决、胜负判定 |
| **可观测性** | 结构化日志：行动、发言、投票、死亡、内心推理（reasoning） |
| **可选 UI** | FastAPI + Vue 观战；支持纯 AI / 人机混战（后续扩展） |

### 1.2 与参考项目的关系

`evo-werewolf-agent` 已验证完整链路，本仓库 **WhoIsWolf** 按相同架构分步实现，可在其基础上：

- **对齐**：目录结构、阶段枚举、API 契约、Agent 输出 JSON 格式  
- **扩展**：作业进阶方向（自演化 / 评测复盘 / 自进化循环）  
- **命名**：对外产品名 **WhoIsWolf**，内部模块名可与参考保持一致便于对照

### 1.3 标准板子（首版范围）

**标准 6 人局采用屠边规则**，仅基础角色：

| 阵营 | 角色 | 胜利条件 |
|------|------|----------|
| 好人 | 预言家、女巫、猎人、村民 | **消灭所有狼人** |
| 狼人 | 狼人 | **屠边**：所有神职死亡 **或** 所有村民死亡 |

> 神职 = 预言家、女巫、猎人；平民 = 村民。  
> `standard_6` 配置 `win_rule: side_elimination`；`simple_4` 等小规模板子可用 `elimination_all_good`。

### 1.4 特殊规则（WhoIsWolf 定制）

| 规则 | 实现位置 |
|------|----------|
| **女巫刀口** | 仅当 `has_heal=true`（解药未用）时，`GameState` 向女巫注入 `tonight_death` |
| **猎人开枪** | 角色状态 `can_shoot`；被毒杀后 `lock_shoot()` 置 false；引擎读状态决定是否调用 Agent 开枪 |
| **角色 Prompt** | `roles/prompts.py`，与 `roles/*.py` 文档一致，由 `PlayerAgent` 注入 |

---

## 2. 系统架构

```mermaid
flowchart TB
    subgraph UI["观战层（可选）"]
        FE[Vue Frontend]
    end

    subgraph API["接口层"]
        HTTP[FastAPI Server]
    end

    subgraph Core["核心层"]
        GE[GameEngine 法官]
        GS[GameState 全局状态]
        ROLES[roles 角色规则]
    end

    subgraph Agents["Agent 层"]
        PA[PlayerAgent × N]
        SA[SummaryAgent]
        JA[JudgeAgent 可选]
    end

    subgraph Data["数据层"]
        SCH[schema 结构化记录]
        LOG[logs 运行日志]
        MEM[memory 跨局经验]
        CFG[config 模型配置]
    end

    FE --> HTTP
    HTTP --> GE
    GE --> GS
    GE --> ROLES
    GE --> PA
    GE --> SA
    GE --> SCH
    GE --> LOG
    PA --> MEM
    PA --> CFG
    SA --> MEM
```

### 2.1 分层职责

| 层级 | 目录 | 职责 |
|------|------|------|
| 角色规则 | `roles/` | 阵营、技能合法性、私有上下文生成、夜间行动类型 |
| 对局引擎 | `engine/` | 阶段状态机、`step()` 推进、收集决策、执行死亡与胜负 |
| 玩家 Agent | `agent/` | LLM 决策：夜间行动 / 发言 / 投票；注入风格与经验 |
| 总结 Agent | `agent/summary_agent.py` | 局后复盘 → 写入 `memory/experiences/` |
| 契约模型 | `schema/` | `GameRecord`、`DialogueRecord`、`GameRunLog` |
| HTTP API | `api/` | 创建对局、单步推进、查询状态、配置列表 |
| 经验记忆 | `memory/` | 按角色类型持久化 lessons，供下局 Prompt 注入 |
| 观战前端 | `frontend/` | 调用 API，展示玩家卡、阶段日志、胜负与总结 |

### 2.2 单局数据流

```
POST /games
  → 加载 ROLE_CONFIGS → shuffle → GameEngine.initialize()
  → 为每位玩家创建 PlayerAgent（私有 context + 决策风格）

循环 POST /games/{id}/step
  → GameEngine.step() 执行当前 _step_index 对应阶段
  → 向存活 PlayerAgent 请求 JSON 决策
  → 引擎校验、结算、写入 dialogues / death_records
  → 返回 StepResponse（本步新增对话、死亡、step_data）

游戏结束（day_end 判定 is_game_over）
  → _step_index = 8 → SummaryAgent 逐人生成总结
  → save_experience(role_type) → 持久化

GET /games/{id} / GET /games/{id}/summaries
  → 前端/复盘读取全量状态
```

---

## 3.0 端到端运行流程

```mermaid
sequenceDiagram
    participant U as 客户端/UI
    participant API as FastAPI
    participant GE as GameEngine
    participant PA as PlayerAgent
    participant SA as SummaryAgent

    U->>API: POST /games (standard_6, shuffle?)
    API->>GE: initialize + 注入狼队友 + win_rule
    GE->>PA: 创建各玩家 Agent（含 roles/prompts）

    loop 每步 POST /games/{id}/step
        GE->>GE: 按 _step_index 执行子阶段
        alt night_wolf / seer / witch
            GE->>PA: decide_night_action(private_context)
            Note over GE: 女巫仅有解药时注入 tonight_death
            PA-->>GE: JSON 决策
        else speech / vote
            GE->>PA: decide_speech / decide_vote
        else night_result / vote后
            GE->>GE: _handle_hunter_death (读 can_shoot)
        end
        GE->>GE: day_end 屠边胜负判定
    end

    GE->>SA: summary 阶段逐人复盘
    SA->>GE: lessons → memory/experiences
    U->>API: GET /games/{id}/summaries
```

**屠边提前终局示例**：6 人局中唯一村民夜间被刀 → 下一步 `step()` 开始时 `is_game_over=true`（神职仍存活但村民已空）→ 跳转 `summary`。

**猎人开枪时机**：`night_result`（被刀）与 `vote`（被放逐）之后；`can_shoot=false` 时跳过。

---

## 3. 对局引擎设计

### 3.1 阶段状态机

参考 `engine/game_engine.py` 的 `_step_index` 设计，**每调用一次 `step()` 推进一个子阶段**：

| index | phase 标识 | 中文阶段 | 引擎行为 |
|-------|------------|----------|----------|
| 0 | `night_wolf` | 狼人杀人 | 狼人 Agent 投票选刀；多数决确定 `night_deaths` |
| 1 | `night_seer` | 预言家查验 | 预言家 Agent 选目标；引擎返回 good/wolf |
| 2 | `night_witch` | 女巫用药 | 解药/毒药各一次；不可自救；单夜不双药 |
| 3 | `night_result` | 夜晚结算 | 宣布死亡；猎人被刀可开枪（被毒则闷枪） |
| 4 | `day_start` | 白天开始 | 公布昨夜信息 |
| 5 | `speech` | 公开演讲 | 存活玩家依次 `decide_speech` |
| 6 | `vote` | 投票环节 | 存活玩家 `decide_vote`；最高票出局 |
| 7 | `day_end` | 日终 | 胜负检查；未结束则 `day_number++`，index 回到 0 |
| 8 | `summary` | 局后总结 | SummaryAgent + 经验入库 |
| -1 | `game_over` | 已结束 | 后续 step 仅返回终局快照 |

```mermaid
stateDiagram-v2
    [*] --> night_wolf
    night_wolf --> night_seer
    night_seer --> night_witch
    night_witch --> night_result
    night_result --> day_start
    day_start --> speech
    speech --> vote
    vote --> day_end
    day_end --> night_wolf: 未结束
    day_end --> summary: 游戏结束
    summary --> game_over
    game_over --> [*]
```

### 3.2 GameEngine 核心接口（内部）

| 方法 | 说明 | 实现要点 |
|------|------|----------|
| `initialize(role_assignment, player_styles?)` | 分配角色、实例化 `Player` 与 `PlayerAgent` | 从 `roles/*` 工厂创建角色对象；构建各玩家 `private_context` |
| `step() -> dict` | 推进一步 | 见上表；返回统一结构供 API 映射为 `StepResponse` |
| `_wolf_kill()` | 狼人夜刀 | 仅狼人可见队友刀口意图；引擎聚票 |
| `_seer_check()` | 预言家查验 | 结果只写入预言家私有 context |
| `_witch_action()` | 女巫用药 | 校验药水次数、目标合法性 |
| `_public_speeches()` | 白天发言 | 按 `speaker_order` 依次调用 Agent |
| `_vote()` | 白天投票 | 计票、平票规则（首版：简单最高票出局） |
| `_run_summaries()` | 局后总结 | 按玩家过滤 `personal_history`，调用 SummaryAgent |
| `is_game_over()` / `get_winner()` | 胜负 | `side_elimination`：狼灭→good；神职空或村民空→evil |

### 3.2.1 屠边判定逻辑（standard_6）

```python
# engine/state.py
alive_wolves = [...]
if not alive_wolves: return True  # good 胜

alive_gods = [seer, witch, hunter 且存活]
alive_villagers = [villager 且存活]
if len(alive_gods) == 0 or len(alive_villagers) == 0:
    return True  # evil 胜（屠边）
```

### 3.3 GameState 与信息隔离

**公开上下文**（`get_public_context`）：天数、阶段、存活列表、公投记录、昨夜死亡名单、**公开阶段对话**（发言、投票）。

**私有上下文**（`get_player_private_context`）：

```python
{
  **public_ctx,
  **player.role.get_private_context(),  # 如：狼队友、查验历史、药水状态
  "dialogues": visible_dialogues,       # 经 _filter_visible_dialogues 过滤
  "other_players": [...],               # 不含他人真实 role（仅 id/name/存活）
}
```

**对话可见性规则**（参考 `engine/state.py`）：

| 对话类型 | 可见范围 |
|----------|----------|
| `phase` 为「公开演讲」「投票」 | 所有存活玩家 |
| 夜间行动（刀人/查验/用药） | 仅行动者本人 |
| 狼人 `night_kill` | 狼人队友可见彼此刀口意图 |

> **实现原则**：引擎在调用 `PlayerAgent` 前组装 context；**禁止**把 `role_assignment` 全表传入 Agent。

### 3.4 角色模块（roles/）

每个角色继承 `BaseRole`，实现：

| 接口 | 用途 |
|------|------|
| `role_type` / `camp` | 枚举：RoleType、Camp |
| `is_night_actionable()` | 是否有夜间行动 |
| `get_night_action(game_state)` | 行动类型与合法目标（规则层，非 LLM） |
| `get_private_context()` | 返回该角色私有信息 dict |
| `can_use_ability(ability)` | 女巫解药/毒药是否可用等 |

| 角色 | 夜间 | 私有信息示例 |
|------|------|----------------|
| 狼人 | 刀人 | 队友 player_id 列表 |
| 预言家 | 查验 | 历史查验 `{target, result}` |
| 女巫 | 用药 | 解药/毒药状态；**有解药时** `tonight_death` 由引擎注入 |
| 猎人 | 无（被动） | **`can_shoot`**：能否开枪（毒杀后为 false） |
| 村民 | 无 | 无额外私有字段 |

**女巫刀口可见性**：

| has_heal | 引擎行为 |
|----------|----------|
| true | `get_player_private_context` 含 `tonight_death`（狼刀目标或 null=平安夜） |
| false | 不注入 `tonight_death`；Prompt 提示不可见刀口 |

**猎人状态字段**（`roles/hunter.py` → 私有 context）：

```json
{ "can_shoot": true, "note": "被毒杀后 can_shoot 为 false" }
```

### 3.5 预置板子配置

与参考项目 `ROLE_CONFIGS` 对齐：

| config_name | 人数 | 组成 | win_rule |
|-------------|------|------|----------|
| `standard_6` | 6 | 2狼 + 预女猎 + 1民 | `side_elimination` |
| `simple_4` | 4 | 1狼 + 预女 + 1民 | `elimination_all_good` |
| `big_9` | 9 | 3狼 + 预女猎 + 2民（白痴未实现） | 待定 |

---

## 4. HTTP API 设计

> 实现文件：`api/server.py`、`api/models.py`  
> 存储：内存字典 `games: Dict[str, GameEngine]`（首版）；后续可换 Redis/DB。

### 4.1 端点总览

| 方法 | 路径 | 功能 |
|------|------|------|
| `GET` | `/` | 健康检查 |
| `POST` | `/games` | 创建并初始化新局 |
| `POST` | `/games/{game_id}/step` | 推进一个子阶段 |
| `GET` | `/games/{game_id}` | 获取完整状态 |
| `GET` | `/games/{game_id}/summaries` | 获取局后总结 |
| `GET` | `/games` | 列出所有活跃对局摘要 |
| `DELETE` | `/games/{game_id}` | 删除对局 |
| `GET` | `/configs` | 列出可用板子 |

### 4.2 `GET /`

**功能**：服务探活。

**响应示例**：

```json
{ "message": "Werewolf Game API", "version": "1.0.0" }
```

**实现**：直接返回静态 JSON，无需 GameEngine。

---

### 4.3 `POST /games` — 创建对局

**功能**：按配置生成角色分配、初始化引擎、注册到 `games` 仓库。

**请求体** `CreateGameRequest`：

| 字段 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `config_name` | string | `standard_6` | 板子名，须在 `ROLE_CONFIGS` 内 |
| `player_names` | list[string] | null | 不传则 `玩家1..N` |
| `shuffle` | bool | true | 是否打乱座位与角色映射 |
| `player_styles` | dict[int, string] | null | 决策风格：`balanced` / `bold` / `cautious` / `random` |

**实现思路**：

1. 校验 `config_name` → `get_role_config()`  
2. 校验 `len(player_names) == player_count`  
3. `shuffle_roles()` 若 `shuffle=true`  
4. `GameEngine(player_names)` → `await initialize(role_assignment, player_styles)`  
5. 生成 `game_id = uuid4()[:8]`，写入 `games[game_id]`  
6. 返回 `GameSummaryResponse`（不含敏感 role 给观战方时，可在前端用「问号」展示，API 层 `players` 在 step 后才逐步暴露）

**响应** `GameSummaryResponse`：

```json
{
  "game_id": "a1b2c3d4",
  "phase": "白天开始",
  "day_number": 1,
  "alive_count": 6,
  "is_game_over": false
}
```

**错误码**：404 未知配置；400 玩家数量不匹配。

---

### 4.4 `POST /games/{game_id}/step` — 推进阶段

**功能**：调用 `engine.step()`，返回本步增量信息。

**实现思路**：

1. `games.get(game_id)` 不存在 → 404  
2. `result = await engine.step()`  
3. 从 `result["step_data"]` 提取 `summaries`（summary 阶段）  
4. 映射为 `StepResponse`

**响应** `StepResponse`：

| 字段 | 说明 |
|------|------|
| `phase` | 英文阶段标识，如 `night_wolf` |
| `day_number` | 当前天数 |
| `step_data` | 本阶段结构化详情（见下表） |
| `players` | 全员快照（含 role，观战模式可用） |
| `dialogues` | **本步新增**对话列表 |
| `deaths` | **本步新增**死亡记录 |
| `is_game_over` | 是否终局 |
| `winner` | `good` / `evil` / null |
| `summaries` | 总结阶段玩家复盘列表 |

**各阶段 `step_data` 约定**：

| phase | step_data 字段 |
|-------|----------------|
| `night_wolf` | `wolf_votes[]`, `final_target` |
| `night_seer` | `seer_id`, `target`, `result`, `reasoning` |
| `night_witch` | `action` (heal/poison), `target` |
| `night_result` | `night_deaths`, `deaths` |
| `day_start` | `{}` |
| `speech` | `speeches[]` {player_id, content} |
| `vote` | `votes` map, `eliminated` |
| `day_end` | `game_over`, `winner`, `next_day` |
| `summary` | `summaries_complete`, `summaries[]` |

**错误处理**：未 `initialize` 的引擎 → 500；已 `game_over` 且 `_step_index=-1` → 仍返回终局快照（不抛错）。

---

### 4.5 `GET /games/{game_id}` — 查询状态

**功能**：任意时刻拉取完整对局快照（调试、前端刷新）。

**响应** `GameStatusResponse`：

| 字段 | 说明 |
|------|------|
| `game_id` | 对局 ID |
| `phase` | 当前阶段中文或英文（与引擎一致） |
| `day_number` | 天数 |
| `players` | 全员列表 |
| `dialogues` | **全量**历史对话 |
| `death_records` | 全量死亡 |
| `winner` | 胜负方 |
| `is_game_over` | 是否结束 |
| `summaries` | 已生成的局后总结 |

**实现**：只读 `engine.game_state` 与 `engine.death_records`、`engine.summaries`，无 LLM 调用。

---

### 4.6 `GET /games/{game_id}/summaries`

**功能**：单独拉取复盘（前端「经验/总结」面板）。

**响应**：

```json
{
  "game_id": "a1b2c3d4",
  "summaries": [
    {
      "player_id": 0,
      "player_name": "玩家1",
      "role": "werewolf",
      "summary": "...",
      "strategies": "...",
      "mistakes": "...",
      "lessons": "..."
    }
  ]
}
```

**实现**：读取 `engine.summaries`；若总结阶段未执行则为空列表。

---

### 4.7 `GET /games` — 列表

**功能**：返回所有内存中对局的摘要字典 `{ game_id: GameSummaryResponse }`。

**实现**：遍历 `games`，不触发 step。

---

### 4.8 `DELETE /games/{game_id}`

**功能**：释放内存，删除引擎实例。

**响应**：`{ "message": "Game {id} deleted" }`

---

### 4.9 `GET /configs`

**功能**：列出可选板子，供前端下拉框使用。

**响应**：

```json
{
  "standard_6": {
    "name": "标准6人局",
    "description": "2狼、1预言家、1女巫、1猎人、1村民",
    "player_count": 6
  }
}
```

**实现**：遍历 `ROLE_CONFIGS`，映射为 `ConfigInfo`。

---

### 4.10 前端对接（观战 UI）

参考 `frontend/src/api.js`，Vite 代理 `/games`、`/configs` → `localhost:8000`。

| 前端能力 | API 组合 |
|----------|----------|
| 新建对局 | `POST /games` |
| 自动观战 | 定时 `POST .../step`（如 2s） |
| 单步/debug | 手动 step |
| 玩家面板 | 最近一步 `players` |
| 日志流 | 累加每步 `dialogues` + `step_data` 渲染 |
| 总结面板 | `GET .../summaries` 或 step 中 `summaries` |

**后续扩展（人机）**：

| 端点（规划） | 说明 |
|--------------|------|
| `POST /games/{id}/human/speech` | 人类玩家提交发言，引擎注入 dialogues |
| `POST /games/{id}/human/vote` | 人类投票 |
| `WS /games/{id}/stream` | WebSocket 推送每步事件（替代轮询） |

---

## 5. 结构化数据与日志

### 5.1 schema 模型

| 模型 | 文件 | 用途 |
|------|------|------|
| `DialogueRecord` | `schema/game_record.py` | 单条决策/发言：day, phase, player_id, action, content, target, reasoning |
| `DeathRecord` | 同上 | 死亡：cause = night_kill / vote / shoot / poison |
| `GameRecord` | 同上 | 整局归档 → `logs/{game_id}.json` |
| `GameRunLog` | `schema/game_logger.py` | 运行过程：分阶段 events、耗时、错误栈 |
| `system_config` | `schema/system_config.py` | 加载 `config/system_config.json`：base_url, api_key, default_model |

### 5.2 日志双轨

| 类型 | 路径 | 内容 |
|------|------|------|
| 业务复盘 | `logs/{game_id}.json` | dialogues、胜负、角色分配、死亡顺序 |
| 运行日志 | `logs/{game_id}_run_log.json` | 阶段耗时、引擎事件、异常 |

**实现思路**：`main_demo.py` 演示时注入 `GameLogger`；API 模式可在 `create_game` 时同样挂载。

### 5.3 Dialogue 的 action 枚举

| action | 阶段 | 记录字段 |
|--------|------|----------|
| `night_kill` | 狼人夜 | target, reasoning |
| `seer_check` | 预言家夜 | target, result, reasoning |
| `heal` / `poison` | 女巫夜 | target |
| `speech` | 白天 | content |
| `vote` | 白天 | target |
| `shoot` | 猎人 | target |

---

## 6. Agent 规划

### 6.1 Agent 全景

```mermaid
flowchart LR
    subgraph Runtime["对局运行时"]
        PA1[PlayerAgent 0]
        PA2[PlayerAgent 1]
        PAN[PlayerAgent N-1]
    end

    subgraph PostGame["局后"]
        SA[SummaryAgent]
    end

    subgraph Optional["可选扩展"]
        JA[JudgeAgent]
        RA[ReplayAgent 复盘官]
        EA[EvolveAgent 策略优化]
    end

    GE[GameEngine] --> PA1
    GE --> PA2
    GE --> PAN
    GE --> SA
    SA --> MEM[(memory/experiences)]
    MEM --> PA1
    PA1 -.-> JA
```

| Agent | 文件 | 数量 | 职责 |
|-------|------|------|------|
| **PlayerAgent** | `agent/player_agent.py` | 每玩家 1 | 夜间行动 / 发言 / 投票；输出 JSON |
| **SummaryAgent** | `agent/summary_agent.py` | 全局 1 | 局后第一人称复盘 → 经验入库 |
| **JudgeAgent** | `agent/player_agent.py` 内 | 0~1 | 公告文案（参考实现偏模板化，可逐步 LLM 化） |
| **BaseAgent** | `agent/base.py` | - | OpenAI Agents SDK 封装、模型配置 |

**技术栈**：`openai-agents`（`Agent` + `Runner.run`）；`config/system_config.json` 指定模型与兼容 API。

### 6.2 PlayerAgent 设计

#### 6.2.1 构造参数

| 参数 | 说明 |
|------|------|
| `player_id` | 座位号 |
| `role_name` | 中文展示名，如「预言家」 |
| `role_type` | 英文 key：`werewolf` / `seer` / ...，用于加载经验 |
| `private_context` | 引擎下发的私有信息 |
| `camp` | `good` / `evil` |
| `decision_style` | 谨慎 / 大胆 / 随机 / 平衡 |

#### 6.2.2 System Instructions 结构

1. 角色与阵营  
2. **`## 角色专属说明`** → `roles/prompts.get_role_prompt(role_type)`（与参考项目 `roles/*.py` 一致）  
3. `## 我的私有信息` → `private_context`（含 `can_shoot` / `knife_target_visible` / `wolf_teammates`）  
4. `## 决策风格` → `DECISION_STYLES[style]`  
5. `## 你的过往游戏经验` → `get_experience_prompt(role_type)`  
6. `## 输出要求` → 强制 JSON schema  

**各角色 Prompt 来源**（`roles/prompts.py`）：

| role_type | 要点 |
|-----------|------|
| werewolf | 屠边胜利、狼队友协调、白天伪装 |
| seer | 每晚查验 good/wolf、报验策略 |
| witch | 解药/毒药限制、**有解药才可见刀口** |
| hunter | **`can_shoot` 状态**、毒杀闷枪 |
| villager | 无夜间技能、纯推理投票 |

#### 6.2.3 三类决策接口

| 方法 | 触发阶段 | Prompt 构建 | 期望 JSON |
|------|----------|-------------|-----------|
| `decide_night_action(game_state)` | 狼/预/女/猎 | `_build_night_prompt` | `{action, target, reasoning?}` |
| `decide_speech(game_state)` | speech | `_build_speech_prompt` | `{action:"speech", content}` |
| `decide_vote(game_state)` | vote | `_build_vote_prompt` | `{action:"vote", target}` |

`game_state` 来源：**必须**是 `GameState.get_player_private_context(player_id)`，而非全局真身表。

#### 6.2.4 输出解析

`_parse_json_output`：正则提取首个 JSON 对象；失败时返回 `{action: "unknown", raw_output}`，引擎层需做**兜底**（随机合法目标 / 跳过投票），避免死局。

#### 6.2.5 决策风格（可调参）

| style | 发言 | 投票 | 夜间 |
|-------|------|------|------|
| `cautious` | 少说少错 | 跟票 | 不轻易用药 |
| `bold` | 激进指控 | 果断出刀 | 冒险刀神 |
| `random` | 直觉 | 随机 | 随机目标 |
| `balanced` | 客观分析 | 理性票 | 合理用药 |

### 6.3 SummaryAgent 设计

**触发**：`GameEngine._step_index == 8`，胜负已定时。

**输入（每玩家）**：

- `personal_history`：经 `_filter_visible_dialogues` 过滤后的文本时间线  
- `role_name`, `camp`, `winner`, `player_name`

**输出 JSON**：

```json
{
  "summary": "整体表现 2-3 句",
  "strategies": "有效/无效策略",
  "mistakes": "失误",
  "lessons": "给未来同角色的建议 1-2 条"
}
```

**落盘**：`save_experience(role_type, {..., is_winner, game_id, timestamp})` → `memory/experiences/{role_type}.json`。

### 6.4 JudgeAgent（弱 Agent / 模板）

当前参考实现主要用于 `announce_death`、`announce_phase` 的文案，**不驱动状态机**。状态机权威在 `GameEngine`。

后续可增强：用 LLM 生成主持人口播，但仍由引擎执行规则。

### 6.5 进阶 Agent（作业三选一，规划占位）

| 方向 | 新增 Agent | 职责 |
|------|------------|------|
| ① 通用→专精 | `MetaAgent` / `PromptEvolver` | 读取 PlayerAgent 源码与 Prompt → 改写 instructions → 沙箱跑测 |
| ② 评测复盘 | `ReplayAgent` | 读 `GameRecord` → 归因（谁聊爆、谁垫飞）→ 输出评分维度 |
| ② Leaderboard | 无 Agent，批处理脚本 | 多模型多局胜率 → `data/leaderboard.json` |
| ③ 自进化 | `CoachAgent` | 聚合 Summary + Replay → 更新 `memory` 或 fine-tune 提示词权重 |

---

## 7. 关键实现细节清单

### 7.1 引擎 ↔ Agent 调用契约

```python
# 伪代码：狼人夜
for wolf in alive_wolves:
    ctx = game_state.get_player_private_context(wolf.player_id)
    decision = await player_agents[wolf.player_id].decide_night_action(ctx)
    # 校验 target 在存活列表且非队友
    record_dialogue(DialogueRecord(..., action="night_kill", ...))
# 聚票确定 final_target
```

### 7.2 胜负判定（GameState）

```text
好人胜：存活狼人数量 == 0
狼人胜：存活好人数量 == 0（或按屠边：神职全灭 OR 平民全灭 — 首版可与参考实现对齐）
```

### 7.3 女巫 / 猎人规则

| 规则 | 实现检查点 |
|------|------------|
| 解药、毒药各 1 次 | `Witch` 角色状态位 |
| 不可自救 | heal 目标 ≠ 女巫本人 |
| 单夜不双药 | 同一 night 阶段二选一 |
| **有解药才见刀口** | `GameState.get_player_private_context` + `knife_target_visible` |
| 猎人毒杀不能开枪 | `cause==poison` → `lock_shoot()`；`_handle_hunter_death` 读 `can_shoot` |
| 猎人夜死/票死可开枪 | `night_result` 与 `_vote` 后均调用 `_handle_hunter_death` |

### 7.4 配置与安全

- `config/system_config.json`：**勿提交真实 api_key**；提供 `system_config.example.json`  
- CORS：开发期 `allow_origins=["*"]`  
- 观战 API 的 `players[].role`：若需隐藏身份，增加 query `?spoiler=false`（规划）

---

## 8. 目录与文件清单

```text
homework/week16/
├── whoiswolf.md          # 本文档
├── main_demo.py          # CLI 最小演示（无 HTTP）
├── requirements.txt
├── config/
│   └── system_config.json
├── roles/                # base, werewolf, seer, witch, hunter, villager, prompts.py
├── engine/               # game_engine, state, phase, player
├── agent/                # base, player_agent, summary_agent
├── api/                  # server.py, models.py
├── schema/               # game_record, game_logger, system_config
├── memory/
│   ├── experience.py
│   └── experiences/*.json
├── logs/
├── tests/
├── frontend/             # Vue 观战（加分）
└── scripts/              # 批跑、评测、Leaderboard
```

---

## 9. 分步实施计划（建议顺序）

| 步骤 | 交付物 | 验收 |
|------|--------|------|
| 1 | `roles/` + 单元测试 | 各角色私有 context、技能合法性 |
| 2 | `engine/state.py`, `phase.py`, `player.py` | 信息隔离过滤正确 |
| 3 | `engine/game_engine.py` + mock Agent | `step` 全流程无 LLM 可跑通 |
| 4 | `agent/player_agent.py` + config | 真实 LLM 决策 JSON 可解析 |
| 5 | `schema/` + `logs/` | `main_demo.py` 产出完整 json |
| 6 | `api/` + `tests/test_api.py` | Swagger 可创建并 step 至终局 |
| 7 | `agent/summary_agent.py` + `memory/` | 第二局同角色 Prompt 含经验 |
| 8 | `frontend/` | 浏览器观战、自动 step |
| 9 | 进阶三选一 | 见第 6.5 节 |

---

## 10. 测试策略

| 模块 | 测试文件 | 要点 |
|------|----------|------|
| roles | `test_werewolf.py` 等 | 私有信息、技能次数 |
| engine | `test_engine.py` | step 顺序、死亡、胜负 |
| schema | `test_schema.py` | pydantic 序列化 |
| agent | `test_player_agent.py` | mock LLM 或录制响应 |
| api | `test_api.py` | TestClient 创建→step→删除 |
| memory | `test_experience.py` | 读写 experiences 文件 |

---

## 11. 参考对照表

| 本项目的概念 | 参考项目路径 |
|--------------|--------------|
| 阶段机 | `evo-werewolf-agent/engine/game_engine.py` |
| API | `evo-werewolf-agent/api/server.py` |
| PlayerAgent | `evo-werewolf-agent/agent/player_agent.py` |
| SummaryAgent | `evo-werewolf-agent/agent/summary_agent.py` |
| 信息隔离 | `evo-werewolf-agent/engine/state.py` |
| 经验记忆 | `evo-werewolf-agent/memory/experience.py` |
| 前端 | `evo-werewolf-agent/frontend/` |
| 开发历程 | `第16周.../狼人杀.claude.txt` |

---

## 12. 附录：PlayerAgent JSON 输出规范

### 夜间（狼人示例）

```json
{
  "action": "night_action",
  "target": 3,
  "reasoning": "玩家3发言划水，且上轮投票异常"
}
```

### 发言

```json
{
  "action": "speech",
  "content": "我目前是好人视角，3号位置不好..."
}
```

### 投票

```json
{
  "action": "vote",
  "target": 3
}
```

跳过投票：`"target": null`

---

*文档版本：v0.2 | 已实现屠边、女巫刀口、猎人 can_shoot、roles/prompts。293 tests passed。*
